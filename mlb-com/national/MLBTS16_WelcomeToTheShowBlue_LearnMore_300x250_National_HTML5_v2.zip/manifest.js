FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShowBlue_LearnMore_300x250_National_v1.html",
	"width":300,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});