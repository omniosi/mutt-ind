FT.manifest({
	"filename": "MLBTS16_PickUpTheSticksBlue_LearnMore_728x90_National_v1.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});