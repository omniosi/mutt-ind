FT.manifest({
	"filename": "MLBTS16_ShootForTheStars_LearnMore_970x66_Houston-Astros.html",
	"width":970,
	"height":66,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});