FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_160x600_Houston-Astros.html",
	"width":160,
	"height":600,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});