FT.manifest({
	"filename": "MLBTS16_RiseUpRedbirdNation_LearnMore_970x66_StLouis-Cardinals.html",
	"width":970,
	"height":66,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});