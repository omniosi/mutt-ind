FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_300x250_StLouis-Cardinals.html",
	"width":300,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});