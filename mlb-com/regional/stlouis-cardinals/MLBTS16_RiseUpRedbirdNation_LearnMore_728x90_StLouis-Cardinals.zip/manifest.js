FT.manifest({
	"filename": "MLBTS16_RiseUpRedbirdNation_LearnMore_728x90_StLouis-Cardinals.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});