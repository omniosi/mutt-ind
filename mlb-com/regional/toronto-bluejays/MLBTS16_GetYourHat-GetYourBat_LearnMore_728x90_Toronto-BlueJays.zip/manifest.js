FT.manifest({
	"filename": "MLBTS16_GetYourHat-GetYourBat_LearnMore_728x90_Toronto-BlueJays.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});