FT.manifest({
	"filename": "MLBTS16_TheShow16_LearnMore_320x50_KC-Royals.html",
	"width":320,
	"height":50,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});