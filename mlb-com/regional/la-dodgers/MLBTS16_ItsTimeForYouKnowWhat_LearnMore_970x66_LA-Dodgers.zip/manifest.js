FT.manifest({
	"filename": "MLBTS16_ItsTimeForYouKnowWhat_LearnMore_970x66_LA-Dodgers.html",
	"width":970,
	"height":66,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});