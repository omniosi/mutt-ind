FT.manifest({
	"filename": "MLBTS16_ItsTimeForYouKnowWhat_LearnMore_728x90_LA-Dodgers.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});