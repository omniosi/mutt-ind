FT.manifest({
	"filename": "MLBTS16_PutOnYourPinstripes_LearnMore_970x66_NY-Yankees.html",
	"width":970,
	"height":66,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});