FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_LearnMore_300x250_Boston-RedSox.html",
	"width":300,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});