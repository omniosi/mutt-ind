FT.manifest({
	"filename": "MLBTS16_PutOnYour-AndDance_LearnMore_728x90_Boston_Red-Sox.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});