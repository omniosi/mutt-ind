FT.manifest({
	"filename": "MLBTS16_PutOnYour-AndDance_LearnMore_970x66_Boston_Red-Sox.html",
	"width":970,
	"height":66,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});