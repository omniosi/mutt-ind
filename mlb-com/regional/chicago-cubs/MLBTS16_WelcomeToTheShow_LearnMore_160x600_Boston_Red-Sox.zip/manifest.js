FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_160x600_Boston_Red-Sox.html",
	"width":160,
	"height":600,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});