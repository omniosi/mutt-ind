FT.manifest({
	"filename": "MLBTS16_ThisYear_LearnMore_728x90_Chicago-Cubs.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});