FT.manifest({
	"filename": "MLBTS16_TheShowIsComingBlue_LearnMore_300x250_National.html",
	"width":300,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});