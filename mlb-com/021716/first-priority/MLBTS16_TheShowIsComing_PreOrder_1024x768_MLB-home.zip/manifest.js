FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_PreOrder_1024x768_MLB-home.html",
	"width":1024,
	"height":768,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});