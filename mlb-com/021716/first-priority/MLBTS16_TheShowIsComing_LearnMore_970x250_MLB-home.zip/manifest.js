FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_LearnMore_970x250_MLB-home.html",
	"width":970,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});