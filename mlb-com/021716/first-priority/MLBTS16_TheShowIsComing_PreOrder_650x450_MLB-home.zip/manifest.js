FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_PreOrder_650x450_MLB-home.html",
	"width":650,
	"height":450,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});