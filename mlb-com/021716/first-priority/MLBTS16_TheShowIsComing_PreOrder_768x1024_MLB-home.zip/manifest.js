FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_PreOrder_768x1024_MLB-home.html",
	"width":768,
	"height":1024,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});