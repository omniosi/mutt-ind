FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_PreOrder_320x480_MLB-home.html",
	"width":320,
	"height":480,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});