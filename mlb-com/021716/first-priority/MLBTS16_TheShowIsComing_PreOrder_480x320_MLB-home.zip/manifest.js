FT.manifest({
	"filename": "MLBTS16_TheShowIsComing_PreOrder_480x320_MLB-home.html",
	"width":480,
	"height":320,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});