FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_480x320_amnet.html",
	"width":480,
	"height":320,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});