FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_650x450_amnet.html",
	"width":650,
	"height":450,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});