FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_160x600_amnet.html",
	"width":160,
	"height":600,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});