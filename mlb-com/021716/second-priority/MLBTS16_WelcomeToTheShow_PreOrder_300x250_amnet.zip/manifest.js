FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_300x250_amnet.html",
	"width":300,
	"height":250,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});