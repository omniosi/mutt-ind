FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_320x480_MLBmobile.html",
	"width":320,
	"height":480,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});