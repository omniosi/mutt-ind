FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_300x600_amnet.html",
	"width":300,
	"height":600,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});