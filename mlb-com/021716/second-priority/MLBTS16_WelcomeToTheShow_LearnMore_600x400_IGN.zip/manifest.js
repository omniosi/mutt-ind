FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_600x400_IGN.html",
	"width":600,
	"height":400,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});