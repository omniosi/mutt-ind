FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_728x90_amnet.html",
	"width":728,
	"height":90,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});