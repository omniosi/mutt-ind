FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_LearnMore_768x1024_amnet.html",
	"width":768,
	"height":1024,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});