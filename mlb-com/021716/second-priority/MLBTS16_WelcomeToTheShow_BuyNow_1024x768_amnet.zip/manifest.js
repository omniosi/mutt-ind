FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_BuyNow_1024x768_amnet.html",
	"width":1024,
	"height":768,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});