FT.manifest({
	"filename": "MLBTS16_WelcomeToTheShow_PreOrder_320x480_amnet.html",
	"width":320,
	"height":480,
	"hideBrowsers":["ie8","opera"],
	"clickTagCount":1
});